
(function($){
	$(function(){

  

	})// End ready function.
   
})(jQuery)

